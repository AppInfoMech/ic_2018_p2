#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>


struct map
{

    char row, col, line;
    char n2, s2, e2, w2;
    char n1, s1, e1, w1;
    char n, s, e, w, p;
    char pl, pl1, pl2, pl3;
    char n_p, s_p, e_p, w_p, p_p;
    int W, L, I, G, B; 
    int W2, L2, I2, G2, B2;
    /////player1///////
    int a0;
    int a1;
    int a2;
    int a3;
    int a4;
    int a5;
    int a6;
    int a7;
    int a8;
    int a9;
    int a10;
    int a11;
    int a12;
    int a13;
    int a14;
    int a15;
    int a16;
    int a17;
    int a18;
    int a19;
    int a20;
    
    int py1_0;
    int py1_1;
    int py1_2;
    int py1_3;
    int py1_4;
    int py1_5;
    int py1_6;
    int py1_7;
    int py1_8;
    int py1_9;
    int py1_10;
    int py1_11;
    int py1_12;
    int py1_13;
    int py1_14;
    int py1_15;
    
    /////player2///////
    int b0;
    int b1;
    int b2;
    int b3;
    int b4;
    int b5;
    int b6;
    int b7;
    int b8;
    int b9;
    int b10;
    int b11;
    int b12;
    int b13;
    int b14;
    int b15;
    int b16;
    int b17;
    int b18;
    int b19;
    int b20;
    
    int py2_0;
    int py2_1;
    int py2_2;
    int py2_3;
    int py2_4;
    int py2_5;
    int py2_6;
    int py2_7;
    int py2_8;
    int py2_9;
    int py2_10;
    int py2_11;
    int py2_12;
    int py2_13;
    int py2_14;
    int py2_15;
///////aldeia//////
    int p_A0;
    int p_A1;
    int p_A2;
    int p_A3;
    int p_A4;
    int p_A5;
    int p_A6;
    int p_A7;
    int p_A8;
    int p_A9;
    int p_A10;
    int p_A11;
    int p_A12;
    int p_A13;
    int p_A14;
    int p_A15;
///////cidade///////    
    int p_C0;
    int p_C1;
    int p_C2;
    int p_C3;
    int p_C4;
    int p_C5;
    int p_C6;
    int p_C7;
    int p_C8;
    int p_C9;
    int p_C10;
    int p_C11;
    int p_C12;
    int p_C13;
    int p_C14;
    int p_C15;

    } map;

int player1Play(int W, int B, int L, int G, int I)
{
    
    srand(time(0));
    printf("Press enter to roll your dice. \n");
    getchar();
    
    int d1_1 = (rand() % 6) + 1;
    int d1_2 = (rand() % 6) + 1;
    int soma = d1_1 + d1_2;

    printf("You rolled a %d and a %d, making a total of %d\n", d1_1, d1_2, soma);
        if (soma == map.a0 || soma == map.a4 || soma == map.a8 || soma == map.a12 || soma == map.a16)
        {
            switch(map.n1)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        if (soma == map.a1 || soma == map.a5 || soma == map.a9 || soma == map.a13 || soma == map.a17)
        {
            switch(map.s1)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        if (soma == map.a2 || soma == map.a6 || soma == map.a10 || soma == map.a14 || soma == map.a18)
        {
            switch(map.e1)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        if (soma == map.a3 || soma == map.a7 || soma == map.a11 || soma == map.a15 || soma == map.a19)
        {
            switch(map.w1)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        
    printf("Your resources are the following: \n");
    printf("Wool: %d    Brick: %d   Lumber: %d   Grain: %d   Iron: %d\n", W, B, L, G, I);


return W, B, L, G, I;
}

int player2Play(int W, int B, int L, int G, int I)
{
    
    srand(time(0));
    printf("Press enter to roll your dice. \n");
    getchar();
    
    int d1_1 = (rand() % 6) + 1;
    int d1_2 = (rand() % 6) + 1;
    int soma = d1_1 + d1_2;

    printf("You rolled a %d and a %d, making a total of %d\n", d1_1, d1_2, soma);
        if (soma == map.a0 || soma == map.a4 || soma == map.a8 || soma == map.a12 || soma == map.a16)
        {
            switch(map.n2)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        if (soma == map.a1 || soma == map.a5 || soma == map.a9 || soma == map.a13 || soma == map.a17)
        {
            switch(map.s2)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;;
            }
        }
        if (soma == map.a2 || soma == map.a6 || soma == map.a10 || soma == map.a14 || soma == map.a18)
        {
            switch(map.e2)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        if (soma == map.a3 || soma == map.a7 || soma == map.a11 || soma == map.a15 || soma == map.a19)
        {
            switch(map.w2)
            {
                case 'W':
                    W = W + 1;
                    printf("Wool: %d\n", W);
                break;
                
                case 'B':
                    B = B + 1;
                    printf("Brick: %d\n", B);
                break;
                
                case 'L':
                    L = L + 1;
                    printf("Lumber: %d\n", L);
                break;
                
                case 'G':
                    G = G + 1;
                    printf("Grain: %d\n", G);
                break;
                
                case 'I':
                    I = I + 1;
                    printf("Iron: %d\n", I);
                break;
            }
        }
        
    printf("Your resources are the following: \n");
    printf("Wool: %d    Brick: %d   Lumber: %d   Grain: %d   Iron: %d\n", W, B, L, G, I);


return W, B, L, G, I;
}

void drawMap()
{
    int i, j, k, v;
    v = 0;
    map.row = 4;
    map.col = 4;
    map.line = 7;

    for(i=0;i<map.row;i++)
    {
        for(j=0;j<map.line;j++)
        {
            for(k=0;k<map.col;k++)
            {
                if( i == 0 && k == 0)
                {
                    map.n = 'D';
                    map.s = 'B';
                    map.e = 'L';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =0;
                    map.s_p =4;
                    map.e_p =11;
                    map.w_p =0;
                    map.p_p = ' ';
                    
                    
                    if (map.p_A0 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        if (map.py1_0 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'B';
                        map.e1 = 'L';
                        map.w1 = 'D';
                        }
                        else if (map.py2_0 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'B';
                        map.e2 = 'L';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C0 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_0 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'B';
                        map.e1 = 'L';
                        map.w1 = 'D';
                        }
                        else if (map.py2_0 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'B';
                        map.e2 = 'L';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                else if(i == 0 && k == 1){
                    map.n = 'D';
                    map.s = 'I';
                    map.e = 'W';
                    map.w = 'L';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =0;
                    map.s_p =6;
                    map.e_p =12;
                    map.w_p =11;
                    map.p_p = ' ';
                    
                    if (map.p_A1 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_1 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'I';
                        map.e1 = 'W';
                        map.w1 = 'L';
                        }
                        else if (map.py2_1 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'I';
                        map.e2 = 'W';
                        map.w2 = 'L';
                        }
                        
                    }
                    if (map.p_C1 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_1 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'I';
                        map.e1 = 'W';
                        map.w1 = 'L';
                        }
                        else if (map.py2_1 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'I';
                        map.e2 = 'W';
                        map.w2 = 'L';
                        }
                    }
                    
                }
                else if(i == 0 && k == 2){
                    map.n = 'D';
                    map.s = 'B';
                    map.e = 'G';
                    map.w = 'W';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =0;
                    map.s_p =5;
                    map.e_p =9;
                    map.w_p =12;
                    map.p_p = ' ';
                    
                    if (map.p_A2 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_2 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'B';
                        map.e1 = 'G';
                        map.w1 = 'W';
                        }
                        else if (map.py2_2 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'B';
                        map.e2 = 'G';
                        map.w2 = 'W';
                        }
                        
                    }
                    if (map.p_C2 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_2 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'B';
                        map.e1 = 'G';
                        map.w1 = 'W';
                        }
                        else if (map.py2_2 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'B';
                        map.e2 = 'G';
                        map.w2 = 'W';
                        }
                    }
                    
                }
                else if(i == 0 && k == 3){
                    map.n = 'D';
                    map.s = 'W';
                    map.e = 'D';
                    map.w = 'G';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =0;
                    map.s_p =10;
                    map.e_p =0;
                    map.w_p =9;
                    
                    if (map.p_A3== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_3 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'W';
                        map.e1 = 'D';
                        map.w1 = 'G';
                        }
                        else if (map.py2_3 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'W';
                        map.e2 = 'D';
                        map.w2 = 'G';
                        }
                        
                    }
                    if (map.p_C3 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_3 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'D';
                        map.s1 = 'W';
                        map.e1 = 'D';
                        map.w1 = 'G';
                        }
                        else if (map.py2_3 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'D';
                        map.s2 = 'W';
                        map.e2 = 'D';
                        map.w2 = 'G';
                        }
                    }
                    
                }
                //////////////////////
                else if( i == 1 && k == 0){
                    map.n = 'B';
                    map.s = 'G';
                    map.e = 'D';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =4;
                    map.s_p =3;
                    map.e_p =0;
                    map.w_p =0;
                    
                    if (map.p_A4== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_4 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'B';
                        map.s1 = 'G';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_4 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'B';
                        map.s2 = 'G';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C4 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_4 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'B';
                        map.s1 = 'G';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_4 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'B';
                        map.s2 = 'G';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                else if(i == 1 && k == 1){
                    map.n = 'I';
                    map.s = 'L';
                    map.e = 'W';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =6;
                    map.s_p =3;
                    map.e_p =10;
                    map.w_p =0;
                    
                    if (map.p_A5== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_5 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'I';
                        map.s1 = 'L';
                        map.e1 = 'W';
                        map.w1 = 'D';
                        }
                        else if (map.py2_5 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'I';
                        map.s2 = 'L';
                        map.e2 = 'W';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C5 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_5 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'I';
                        map.s1 = 'L';
                        map.e1 = 'W';
                        map.w1 = 'D';
                        }
                        else if (map.py2_5 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'I';
                        map.s2 = 'L';
                        map.e2 = 'W';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                else if(i == 1 && k == 2){
                    map.n = 'B';
                    map.s = 'G';
                    map.e = 'D';
                    map.w = 'W';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =5;
                    map.s_p =11;
                    map.e_p =0;
                    map.w_p =10;
                    
                    if (map.p_A6== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_6 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'B';
                        map.s1 = 'G';
                        map.e1 = 'D';
                        map.w1 = 'W';
                        }
                        else if (map.py2_6 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'B';
                        map.s2 = 'G';
                        map.e2 = 'D';
                        map.W2 = 'W';
                        }
                        
                    }
                    if (map.p_C6 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_6 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'B';
                        map.s1 = 'G';
                        map.e1 = 'D';
                        map.w1 = 'W';
                        }
                        else if (map.py2_6 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'B';
                        map.s2 = 'G';
                        map.e2 = 'D';
                        map.W2 = 'W';
                        }
                    }
                    
                }
                else if(i == 1 && k == 3){
                    map.n = 'W';
                    map.s = 'L';
                    map.e = 'D';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    map.n_p =10;
                    map.s_p =4;
                    map.e_p =0;
                    map.w_p =0;
                    
                    if (map.p_A7== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_7 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'W';
                        map.s1 = 'L';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_7 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'W';
                        map.s2 = 'L';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C7 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_7 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'W';
                        map.s1 = 'L';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_7 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'W';
                        map.s2 = 'L';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                ///////////////////////
                else if( i == 2 && k == 0){
                    map.n = 'G';
                    map.s = 'B';
                    map.e = 'D';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =3;
                    map.s_p =8;
                    map.e_p =0;
                    map.w_p =0;
                    
                   if (map.p_A8== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_8 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'G';
                        map.s1 = 'B';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_8 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'G';
                        map.s2 = 'B';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C8 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                       
                        
                        if (map.py1_8 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'G';
                        map.s1 = 'B';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_8 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'G';
                        map.s2 = 'B';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                    } 
                    
                }
                else if(i == 2 && k == 1){
                    map.n = 'L';
                    map.s = 'W';
                    map.e = 'W';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =3;
                    map.s_p =10;
                    map.e_p =9;
                    map.w_p =0;
                    
                    if (map.p_A9== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_9 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'L';
                        map.s1 = 'W';
                        map.e1 = 'W';
                        map.w1 = 'D';
                        }
                        else if (map.py2_9 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'L';
                        map.s2 = 'W';
                        map.e2 = 'W';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C9 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_9 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'L';
                        map.s1 = 'W';
                        map.e1 = 'W';
                        map.w1 = 'D';
                        }
                        else if (map.py2_9 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'L';
                        map.s2 = 'W';
                        map.e2 = 'W';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                else if(i == 2 && k == 2){
                    map.n = 'G';
                    map.s = 'W';
                    map.e = 'D';
                    map.w = 'W';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =11;
                    map.s_p =10;
                    map.e_p =0;
                    map.w_p =9;
                    
                    if (map.p_A10== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                       
                        
                        if (map.py1_10 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'G';
                        map.s1 = 'W';
                        map.e1 = 'D';
                        map.w1 = 'W';
                        }
                        else if (map.py2_10 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'G';
                        map.s2 = 'W';
                        map.e2 = 'D';
                        map.w2 = 'W';
                        }
                        
                    }
                    if (map.p_C10 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_10 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'G';
                        map.s1 = 'W';
                        map.e1 = 'D';
                        map.w1 = 'W';
                        }
                        else if (map.py2_10 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'G';
                        map.s2 = 'W';
                        map.e2 = 'D';
                        map.w2 = 'W';
                        }
                    }
                    
                }
                else if(i == 2 && k == 3){
                    map.n = 'L';
                    map.s = 'I';
                    map.e = 'D';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    map.n_p =4;
                    map.s_p =3;
                    map.e_p =0;
                    map.w_p =0;
                    
                    if (map.p_A11== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_11 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'L';
                        map.s1 = 'I';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_11 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'L';
                        map.s2 = 'I';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C11 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_11 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'L';
                        map.s1 = 'I';
                        map.e1 = 'D';
                        map.w1 = 'D';
                        }
                        else if (map.py2_11 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'L';
                        map.s2 = 'I';
                        map.e2 = 'D';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                ///////////////////////
                else if( i == 3 && k == 0){
                    map.n = 'B';
                    map.s = 'D';
                    map.e = 'I';
                    map.w = 'D';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =8;
                    map.s_p =0;
                    map.e_p =5;
                    map.w_p =0;
                    
                    if (map.p_A12== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_12 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'B';
                        map.s1 = 'D';
                        map.e1 = 'I';
                        map.w1 = 'D';
                        }
                        else if (map.py2_12 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'B';
                        map.s2 = 'D';
                        map.e2 = 'I';
                        map.w2 = 'D';
                        }
                        
                    }
                    if (map.p_C12 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_12 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'B';
                        map.s1 = 'D';
                        map.e1 = 'I';
                        map.w1 = 'D';
                        }
                        else if (map.py2_12 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'B';
                        map.s2 = 'D';
                        map.e2 = 'I';
                        map.w2 = 'D';
                        }
                    }
                    
                }
                else if(i == 3 && k == 1){
                    map.n = 'W';
                    map.s = 'D';
                    map.e = 'G';
                    map.w = 'I';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    map.n_p =10;
                    map.s_p =0;
                    map.e_p =2;
                    map.w_p =1;
                    
                    if (map.p_A13== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_13 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'W';
                        map.s1 = 'D';
                        map.e1 = 'G';
                        map.w1 = 'I';
                        }
                        else if (map.py2_13 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'W';
                        map.s2 = 'D';
                        map.e2 = 'G';
                        map.w2 = 'I';
                        }
                        
                    }
                    if (map.p_C13 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_13 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'W';
                        map.s1 = 'D';
                        map.e1 = 'G';
                        map.w1 = 'I';
                        }
                        else if (map.py2_13 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'W';
                        map.s2 = 'D';
                        map.e2 = 'G';
                        map.w2 = 'I';
                        }
                    }
                    
                }
                else if(i == 3 && k == 2){
                    map.n = 'W';
                    map.s = 'D';
                    map.e = 'L';
                    map.w = 'G';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =10;
                    map.s_p =0;
                    map.e_p =6;
                    map.w_p =2;
                    
                    if (map.p_A14== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_14 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'W';
                        map.s1 = 'D';
                        map.e1 = 'L';
                        map.w1 = 'G';
                        }
                        else if (map.py2_14 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'W';
                        map.s2 = 'D';
                        map.e2 = 'L';
                        map.w2 = 'G';
                        }
                        
                    }
                    if (map.p_C14 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_14 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'W';
                        map.s1 = 'D';
                        map.e1 = 'L';
                        map.w1 = 'G';
                        }
                        else if (map.py2_14 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'W';
                        map.s2 = 'D';
                        map.e2 = 'L';
                        map.w2 = 'G';
                        }
                    }
                    
                }
                else if(i == 3 && k == 3){
                    map.n = 'I';
                    map.s = 'D';
                    map.e = 'D';
                    map.w = 'L';
                    map.pl = ' ';
                    map.pl1 = ' ';
                    map.pl2 = ' ';
                    map.p_p = ' ';
                    map.pl3 = ' ';
                    map.p = ' ';
                    
                    map.n_p =3;
                    map.s_p =0;
                    map.e_p =0;
                    map.w_p =6;
                    
                    if (map.p_A15== 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'A';
                        map.pl3 = ')';
                        
                        
                        
                        if (map.py1_15 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'I';
                        map.s1 = 'D';
                        map.e1 = 'D';
                        map.w1 = 'L';
                        }
                        else if (map.py2_15 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'I';
                        map.s2 = 'D';
                        map.e2 = 'D';
                        map.w2 = 'L';
                        }
                        
                    }
                    if (map.p_C15 == 1)
                    {
                        map.pl = 'P';
                        map.pl1 = 'L';
                        map.pl2 = '(';
                        map.p_p = 'C';
                        map.pl3 = ')';
                        

                        
                        if (map.py1_15 ==  1)
                        {
                        map.p = '1';
                        
                        map.n1 = 'I';
                        map.s1 = 'D';
                        map.e1 = 'D';
                        map.w1 = 'L';
                        }
                        else if (map.py2_15 ==  1)
                        {
                        map.p = '2';
                        
                        map.n2 = 'I';
                        map.s2 = 'D';
                        map.e2 = 'D';
                        map.w2 = 'L';
                        }
                    }
                    
                }
                
                
                switch(j)
                {
                    case 0:
                    printf("+--------------");
                    break;

                    case 1:
                    printf("|      #%2d     ", v++);
                    break;

                    case 2:
                    printf("|  N:%c(%2d)     ", map.n, map.n_p );
                    break;

                    case 3:
                    printf("|  S:%c(%2d)     ", map.s, map.s_p);
                    break;

                    case 4:
                    printf("|  E:%c(%2d)     ", map.e, map.e_p);
                    break;

                    case 5:
                    printf("|  W:%c(%2d)     ", map.w, map.w_p);
                    break;

                    case 6:
                    printf("|  %c%c%c%c%c%c      ", map.pl, map.pl1, map.p, map.pl2, map.p_p, map.pl3);
                    break;
                }
            }
            printf("|");
            printf("\n");
        }
    }
    for(i=0;i<map.col;i++)
    {
        printf("+--------------");
    }
    printf("\n");
    
}

int main()
{
    map.W = 0;
    map.L = 0;
    map.I = 0;
    map.G = 0;
    map.B = 0;
    
    map.W2 = 0;
    map.L2 = 0;
    map.I2 = 0;
    map.G2 = 0;
    map.B2 = 0;
    
    int player1_points = 1;
    int player2_points = 1;
    
    char escolha, escolha2, escolha3, recurso;
    drawMap();
    printf("W - wool,   B - brick,    L - lumber\n");
    printf("G - grain,  I - Iron,     D - Desert\n");
    printf("P1 Choose the starting location (the numbers are hexadecimal): ");
    scanf("%s", &escolha);
        switch(escolha)
                {
                    case '0':
                    map.py1_0 = 1;
                    map.p_A0 = 1;
                    //centro
                    map.a0 = 0;
                    map.a1 = 4;
                    map.a2 = 11;
                    map.a3 = 0;
                    //direita
                    map.a4 = 0;
                    map.a5 = 6;
                    map.a6 = 12;
                    map.a7 = 11;
                    //baixo
                    map.a8 = 4;
                    map.a9 = 3;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 0;
                    map.a14 = 0;
                    map.a15 = 0;
                    //cima
                    map.a16 = 0;
                    map.a17 = 0;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;

                    case '1':
                    map.py1_1 = 1;
                    map.p_A1 = 1;
                    //centro
                    map.a0 = 0;
                    map.a1 = 6;
                    map.a2 = 12;
                    map.a3 = 11;
                    //direita
                    map.a4 = 0;
                    map.a5 = 5;
                    map.a6 = 9;
                    map.a7 = 12;
                    //baixo
                    map.a8 = 6;
                    map.a9 = 3;
                    map.a10 = 10;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 4;
                    map.a14 = 11;
                    map.a15 = 0;
                    //cima
                    map.a16 = 0;
                    map.a17 = 0;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;

                    case '2':
                    map.py1_2 = 1;
                    map.p_A2 = 1;
                    //centro
                    map.a0 = 0;
                    map.a1 = 5;
                    map.a2 = 9;
                    map.a3 = 12;
                    //direita
                    map.a4 = 0;
                    map.a5 = 10;
                    map.a6 = 0;
                    map.a7 = 9;
                    //baixo
                    map.a8 = 5;
                    map.a9 = 11;
                    map.a10 = 0;
                    map.a11 = 10;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 6;
                    map.a14 = 12;
                    map.a15 = 11;
                    //cima
                    map.a16 = 0;
                    map.a17 = 0;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;

                    case '3':
                    map.py1_3 = 1;
                    map.p_A3 = 1;
                    //centro
                    map.a0 = 0;
                    map.a1 = 10;
                    map.a2 = 0;
                    map.a3 = 9;
                    //direita
                    map.a4 = 0;
                    map.a5 = 0;
                    map.a6 = 0;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 10;
                    map.a9 = 4;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 5;
                    map.a14 = 9;
                    map.a15 = 12;
                    //cima
                    map.a16 = 0;
                    map.a17 = 0;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;

                    case '4':
                    map.py1_4 = 1;
                    map.p_A4 = 1;
                    //centro
                    map.a0 = 4;
                    map.a1 = 3;
                    map.a2 = 0;
                    map.a3 = 0;
                    //direita
                    map.a4 = 6;
                    map.a5 = 3;
                    map.a6 = 10;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 3;
                    map.a9 = 6;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 0;
                    map.a14 = 0;
                    map.a15 = 0;
                    //cima
                    map.a16 = 0;
                    map.a17 = 4;
                    map.a18 = 11;
                    map.a19 = 0;
                    break;

                    case '5':
                    map.py1_5 = 1;
                    map.p_A5 = 1;
                    //centro
                    map.a0 = 6;
                    map.a1 = 3;
                    map.a2 = 10;
                    map.a3 = 0;
                    //direita
                    map.a4 = 5;
                    map.a5 = 11;
                    map.a6 = 0;
                    map.a7 = 10;
                    //baixo
                    map.a8 = 3;
                    map.a9 = 10;
                    map.a10 = 9;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 4;
                    map.a13 = 3;
                    map.a14 = 0;
                    map.a15 = 0;
                    //cima
                    map.a16 = 0;
                    map.a17 = 6;
                    map.a18 = 12;
                    map.a19 = 11;
                    break;

                    case '6':
                    map.py1_6 = 1;
                    map.p_A6 = 1;
                    //centro
                    map.a0 = 5;
                    map.a1 = 11;
                    map.a2 = 0;
                    map.a3 = 10;
                    //direita
                    map.a4 = 10;
                    map.a5 = 4;
                    map.a6 = 0;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 11;
                    map.a9 = 10;
                    map.a10 = 0;
                    map.a11 = 9;
                    //esquerda
                    map.a12 = 6;
                    map.a13 = 3;
                    map.a14 = 10;
                    map.a15 = 0;
                    //cima
                    map.a16 = 0;
                    map.a17 = 5;
                    map.a18 = 9;
                    map.a19 = 12;
                    break;
                    
                    case '7':
                    map.py1_7 = 1;
                    map.p_A7 = 1;
                    //centro
                    map.a0 = 10;
                    map.a1 = 4;
                    map.a2 = 0;
                    map.a3 = 0;
                    //direita
                    map.a4 = 0;
                    map.a5 = 0;
                    map.a6 = 0;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 4;
                    map.a9 = 3;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 5;
                    map.a13 = 11;
                    map.a14 = 0;
                    map.a15 = 10;
                    //cima
                    map.a16 = 0;
                    map.a17 = 10;
                    map.a18 = 0;
                    map.a19 = 9;
                    break;
                    
                    case '8':
                    map.py1_8 = 1;
                    map.p_A8 = 1;
                    //centro
                    map.a0 = 3;
                    map.a1 = 8;
                    map.a2 = 0;
                    map.a3 = 0;
                    //direita
                    map.a4 = 3;
                    map.a5 = 10;
                    map.a6 = 9;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 8;
                    map.a9 = 0;
                    map.a10 = 5;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 0;
                    map.a14 = 0;
                    map.a15 = 0;
                    //cima
                    map.a16 = 4;
                    map.a17 = 3;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;
                    
                    case '9':
                    map.py1_9 = 1;
                    map.p_A9 = 1;
                    //centro
                    map.a0 = 3;
                    map.a1 = 10;
                    map.a2 = 9;
                    map.a3 = 0;
                    //direita
                    map.a4 = 11;
                    map.a5 = 10;
                    map.a6 = 0;
                    map.a7 = 9;
                    //baixo
                    map.a8 = 10;
                    map.a9 = 0;
                    map.a10 = 2;
                    map.a11 = 5;
                    //esquerda
                    map.a12 = 3;
                    map.a13 = 8;
                    map.a14 = 0;
                    map.a15 = 0;
                    //cima
                    map.a16 = 6;
                    map.a17 = 3;
                    map.a18 = 10;
                    map.a19 = 0;
                    break;
                    
                    case 'a':
                    map.py1_10 = 1;
                    map.p_A10 = 1;
                    //centro
                    map.a0 = 11;
                    map.a1 = 10;
                    map.a2 = 0;
                    map.a3 = 9;
                    //direita
                    map.a4 = 4;
                    map.a5 = 3;
                    map.a6 = 0;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 10;
                    map.a9 = 0;
                    map.a10 = 6;
                    map.a11 = 2;
                    //esquerda
                    map.a12 = 3;
                    map.a13 = 10;
                    map.a14 = 9;
                    map.a15 = 0;
                    //cima
                    map.a16 = 5;
                    map.a17 = 11;
                    map.a18 = 0;
                    map.a19 = 10;
                    break;
                    
                    case 'b':
                    map.py1_11 = 1;
                    map.p_A11 = 1;
                    //centro
                    map.a0 = 4;
                    map.a1 = 3;
                    map.a2 = 0;
                    map.a3 = 0;
                    //direita
                    map.a4 = 0;
                    map.a5 = 0;
                    map.a6 = 0;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 3;
                    map.a9 = 0;
                    map.a10 = 0;
                    map.a11 = 6;
                    //esquerda
                    map.a12 = 11;
                    map.a13 = 10;
                    map.a14 = 0;
                    map.a15 = 9;
                    //cima
                    map.a16 = 10;
                    map.a17 = 4;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;
                    
                    case 'c':
                    map.py1_12 = 1;
                    map.p_A12 = 1;
                    //centro
                    map.a0 = 8;
                    map.a1 = 0;
                    map.a2 = 5;
                    map.a3 = 0;
                    //direita
                    map.a4 = 10;
                    map.a5 = 0;
                    map.a6 = 2;
                    map.a7 = 5;
                    //baixo
                    map.a8 = 0;
                    map.a9 = 0;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 0;
                    map.a13 = 0;
                    map.a14 = 0;
                    map.a15 = 0;
                    //cima
                    map.a16 = 3;
                    map.a17 = 8;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;
                    
                    case 'd':
                    map.py1_13 = 1;
                    map.p_A13 = 1;
                    //centro
                    map.a0 = 10;
                    map.a1 = 0;
                    map.a2 = 2;
                    map.a3 = 5;
                    //direita
                    map.a4 = 10;
                    map.a5 = 0;
                    map.a6 = 6;
                    map.a7 = 2;
                    //baixo
                    map.a8 = 0;
                    map.a9 = 0;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 8;
                    map.a13 = 0;
                    map.a14 = 5;
                    map.a15 = 0;
                    //cima
                    map.a16 = 3;
                    map.a17 = 10;
                    map.a18 = 9;
                    map.a19 = 0;
                    break;
                    
                    case 'e':
                    map.py1_14 = 1;
                    map.p_A14 = 1;
                    //centro
                    map.a0 = 10;
                    map.a1 = 0;
                    map.a2 = 6;
                    map.a3 = 2;
                    //direita
                    map.a4 = 3;
                    map.a5 = 0;
                    map.a6 = 0;
                    map.a7 = 6;
                    //baixo
                    map.a8 = 0;
                    map.a9 = 0;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 10;
                    map.a13 = 0;
                    map.a14 = 2;
                    map.a15 = 5;
                    //cima
                    map.a16 = 11;
                    map.a17 = 10;
                    map.a18 = 0;
                    map.a19 = 9;
                    break;
                    
                    case 'f':
                    map.py1_15 = 1;
                    map.p_A15 = 1;
                    //centro
                    map.a0 = 3;
                    map.a1 = 0;
                    map.a2 = 0;
                    map.a3 = 6;
                    //direita
                    map.a4 = 0;
                    map.a5 = 0;
                    map.a6 = 0;
                    map.a7 = 0;
                    //baixo
                    map.a8 = 0;
                    map.a9 = 0;
                    map.a10 = 0;
                    map.a11 = 0;
                    //esquerda
                    map.a12 = 10;
                    map.a13 = 0;
                    map.a14 = 6;
                    map.a15 = 2;
                    //cima
                    map.a16 = 4;
                    map.a17 = 3;
                    map.a18 = 0;
                    map.a19 = 0;
                    break;
                    
                    default:
                    printf("thats not an option!\n");
                    break;
                }
    
    printf("P2 Choose the starting location (the numbers are hexadecimal): ");            
    scanf("%s", &escolha2);
    while (true){
        if (escolha2 != escolha){
            switch(escolha2)
                {
                    case '0':
                    map.py2_0 = 1;
                    map.p_A0 = 1;
                     //centro
                    map.b0 = 0;
                    map.b1 = 4;
                    map.b2 = 11;
                    map.b3 = 0;
                    //direita
                    map.b4 = 0;
                    map.b5 = 6;
                    map.b6 = 12;
                    map.b7 = 11;
                    //baixo
                    map.b8 = 4;
                    map.b9 = 3;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 0;
                    map.b13 = 0;
                    map.b14 = 0;
                    map.b15 = 0;
                    //cima
                    map.b16 = 0;
                    map.b17 = 0;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
    
                    case '1':
                    map.py2_1 = 1;
                    map.p_A1 = 1;
                    //centro
                    map.b0 = 0;
                    map.b1 = 6;
                    map.b2 = 12;
                    map.b3 = 11;
                    //direita
                    map.b4 = 0;
                    map.b5 = 5;
                    map.b6 = 9;
                    map.b7 = 12;
                    //baixo
                    map.b8 = 6;
                    map.b9 = 3;
                    map.b10 = 10;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 0;
                    map.b13 = 4;
                    map.b14 = 11;
                    map.b15 = 0;
                    //cima
                    map.b16 = 0;
                    map.b17 = 0;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
    
                    case '2':
                    map.py2_2 = 1;
                    map.p_A2 = 1;
                     //centro
                    map.b0 = 0;
                    map.b1 = 5;
                    map.b2 = 9;
                    map.b3 = 12;
                    //direita
                    map.b4 = 0;
                    map.b5 = 10;
                    map.b6 = 0;
                    map.b7 = 9;
                    //baixo
                    map.b8 = 5;
                    map.b9 = 11;
                    map.b10 = 0;
                    map.b11 = 10;
                    //esquerda
                    map.b12 = 0;
                    map.b13 = 6;
                    map.b14 = 12;
                    map.b15 = 11;
                    //cima
                    map.b16 = 0;
                    map.b17 = 0;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
    
                    case '3':
                    map.py2_3 = 1;
                    map.p_A3 = 1;
                    //centro
                    map.b0 = 0;
                    map.b1 = 10;
                    map.b2 = 0;
                    map.b3 = 9;
                    //direita
                    map.b4 = 0;
                    map.b5 = 0;
                    map.b6 = 0;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 10;
                    map.b9 = 4;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 0;
                    map.b13 = 5;
                    map.b14 = 9;
                    map.b15 = 12;
                    //cima
                    map.b16 = 0;
                    map.b17 = 0;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
    
                    case '4':
                    map.py2_4 = 1;
                    map.p_A4 = 1;
                    //centro
                    map.b0 = 4;
                    map.b1 = 3;
                    map.b2 = 0;
                    map.b3 = 0;
                    //direita
                    map.b4 = 6;
                    map.b5 = 3;
                    map.b6 = 10;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 3;
                    map.b9 = 6;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 0;
                    map.b13 = 0;
                    map.b14 = 0;
                    map.b15 = 0;
                    //cima
                    map.b16 = 0;
                    map.b17 = 4;
                    map.b18 = 11;
                    map.b19 = 0;
                    break;
    
                    case '5':
                    map.py2_5 = 1;
                    map.p_A5 = 1;
                    //centro
                    map.b0 = 6;
                    map.b1 = 3;
                    map.b2 = 10;
                    map.b3 = 0;
                    //direita
                    map.b4 = 5;
                    map.b5 = 11;
                    map.b6 = 0;
                    map.b7 = 10;
                    //baixo
                    map.b8 = 3;
                    map.b9 = 10;
                    map.b10 = 9;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 4;
                    map.b13 = 3;
                    map.b14 = 0;
                    map.b15 = 0;
                    //cima
                    map.b16 = 0;
                    map.b17 = 6;
                    map.b18 = 12;
                    map.b19 = 11;
                    break;
    
                    case '6':
                    map.py2_6 = 1;
                    map.p_A6 = 1;
                    //centro
                    map.b0 = 5;
                    map.b1 = 11;
                    map.b2 = 0;
                    map.b3 = 10;
                    //direita
                    map.b4 = 10;
                    map.b5 = 4;
                    map.b6 = 0;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 11;
                    map.b9 = 10;
                    map.b10 = 0;
                    map.b11 = 9;
                    //esquerda
                    map.b12 = 6;
                    map.b13 = 3;
                    map.b14 = 10;
                    map.b15 = 0;
                    //cima
                    map.b16 = 0;
                    map.b17 = 5;
                    map.b18 = 9;
                    map.b19 = 12;
                    break;
                        
                    case '7':
                    map.py2_7 = 1;
                    map.p_A7 = 1;
                    break;
                        
                    case '8':
                    map.py2_8 = 1;
                    map.p_A8 = 1;
                    //centro
                    map.b0 = 10;
                    map.b1 = 4;
                    map.b2 = 0;
                    map.b3 = 0;
                    //direita
                    map.b4 = 0;
                    map.b5 = 0;
                    map.b6 = 0;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 4;
                    map.b9 = 3;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 5;
                    map.b13 = 11;
                    map.b14 = 0;
                    map.b15 = 10;
                    //cima
                    map.b16 = 0;
                    map.b17 = 10;
                    map.b18 = 0;
                    map.b19 = 9;
                    break;
                        
                    case '9':
                    map.py2_9 = 1;
                    map.p_A9 = 1;
                    //centro
                    map.b0 = 3;
                    map.b1 = 10;
                    map.b2 = 9;
                    map.b3 = 0;
                    //direita
                    map.b4 = 11;
                    map.b5 = 10;
                    map.b6 = 0;
                    map.b7 = 9;
                    //baixo
                    map.b8 = 10;
                    map.b9 = 0;
                    map.b10 = 2;
                    map.b11 = 5;
                    //esquerda
                    map.b12 = 3;
                    map.b13 = 8;
                    map.b14 = 0;
                    map.b15 = 0;
                    //cima
                    map.b16 = 6;
                    map.b17 = 3;
                    map.b18 = 10;
                    map.b19 = 0;
                    break;
                        
                    case 'a':
                    map.py2_10 = 1;
                    map.p_A10 = 1;
                    //centro
                    map.b0 = 11;
                    map.b1 = 10;
                    map.b2 = 0;
                    map.b3 = 9;
                    //direita
                    map.b4 = 4;
                    map.b5 = 3;
                    map.b6 = 0;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 10;
                    map.b9 = 0;
                    map.b10 = 6;
                    map.b11 = 2;
                    //esquerda
                    map.b12 = 3;
                    map.b13 = 10;
                    map.b14 = 9;
                    map.b15 = 0;
                    //cima
                    map.b16 = 5;
                    map.b17 = 11;
                    map.b18 = 0;
                    map.b19 = 10;
                    break;
                        
                    case 'b':
                    map.py2_11 = 1;
                    map.p_A11 = 1;
                    //centro
                    map.b0 = 4;
                    map.b1 = 3;
                    map.b2 = 0;
                    map.b3 = 0;
                    //direita
                    map.b4 = 0;
                    map.b5 = 0;
                    map.b6 = 0;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 3;
                    map.b9 = 0;
                    map.b10 = 0;
                    map.b11 = 6;
                    //esquerda
                    map.b12 = 11;
                    map.b13 = 10;
                    map.b14 = 0;
                    map.b15 = 9;
                    //cima
                    map.b16 = 10;
                    map.b17 = 4;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
                        
                    case 'c':
                    map.py2_12 = 1;
                    map.p_A12 = 1;
                    //centro
                    map.b0 = 8;
                    map.b1 = 0;
                    map.b2 = 5;
                    map.b3 = 0;
                    //direita
                    map.b4 = 10;
                    map.b5 = 0;
                    map.b6 = 2;
                    map.b7 = 5;
                    //baixo
                    map.b8 = 0;
                    map.b9 = 0;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 0;
                    map.b13 = 0;
                    map.b14 = 0;
                    map.b15 = 0;
                    //cima
                    map.b16 = 3;
                    map.b17 = 8;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
                        
                    case 'd':
                    map.py2_13 = 1;
                    map.p_A13 = 1;
                    //centro
                    map.b0 = 10;
                    map.b1 = 0;
                    map.b2 = 2;
                    map.b3 = 5;
                    //direita
                    map.b4 = 10;
                    map.b5 = 0;
                    map.b6 = 6;
                    map.b7 = 2;
                    //baixo
                    map.b8 = 0;
                    map.b9 = 0;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 8;
                    map.b13 = 0;
                    map.b14 = 5;
                    map.b15 = 0;
                    //cima
                    map.b16 = 3;
                    map.b17 = 10;
                    map.b18 = 9;
                    map.b19 = 0;
                    break;
                        
                    case 'e':
                    map.py2_14 = 1;
                    map.p_A14 = 1;
                    //centro
                    map.b0 = 10;
                    map.b1 = 0;
                    map.b2 = 6;
                    map.b3 = 2;
                    //direita
                    map.b4 = 3;
                    map.b5 = 0;
                    map.b6 = 0;
                    map.b7 = 6;
                    //baixo
                    map.b8 = 0;
                    map.b9 = 0;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 10;
                    map.b13 = 0;
                    map.b14 = 2;
                    map.b15 = 5;
                    //cima
                    map.b16 = 11;
                    map.b17 = 10;
                    map.b18 = 0;
                    map.b19 = 9;
                    break;
                        
                    case 'f':
                    map.py2_15 = 1;
                    map.p_A15 = 1;
                    //centro
                    map.b0 = 3;
                    map.b1 = 0;
                    map.b2 = 0;
                    map.b3 = 6;
                    //direita
                    map.b4 = 0;
                    map.b5 = 0;
                    map.b6 = 0;
                    map.b7 = 0;
                    //baixo
                    map.b8 = 0;
                    map.b9 = 0;
                    map.b10 = 0;
                    map.b11 = 0;
                    //esquerda
                    map.b12 = 10;
                    map.b13 = 0;
                    map.b14 = 6;
                    map.b15 = 2;
                    //cima
                    map.b16 = 4;
                    map.b17 = 3;
                    map.b18 = 0;
                    map.b19 = 0;
                    break;
                        
                    default:
                    printf("That's not an option!\n");
                    break;
                    }
            break;
        }
    }
    while (true){
        drawMap();
        printf("PL1 choose your action\n");
        printf("r - to roll dice\n");
        printf("p - to use 10 resources to get 1 point\n");
        scanf("%s",&escolha3);
            switch(escolha3){
                case 'r':
                    player1Play(map.W, map.B, map.L, map.G, map.I);
                break;
                
                case 'p':
                    if (map.W >= 10 || map.B >= 10 || map.L >= 10 || map.G >= 10 || map.I >= 10 ){
                        printf("W -(%d)wool,   B - (%d)brick,    L -(%d)lumber\n", map.W2, map.B, map.L2);
                        printf("G -(%d)grain,  I -(%d)Iron\n", map.G, map.I);
                        printf("Which resource will you use? ");
                        scanf("%s", &recurso);
                            switch(recurso){
                                case 'W':
                                    map.W = map.W - 10;
                                    player1_points = player1_points + 1;
                                    printf("You now have %d points!", player1_points);
                                break;
                                case 'B':
                                    map.B = map.B - 10;
                                    player1_points = player1_points + 1;
                                    printf("You now have %d points!", player1_points);
                                break;
                                case 'L':
                                    map.L = map.L - 10;
                                    player1_points = player1_points + 1;
                                    printf("You now have %d points!", player1_points);
                                break;
                                case 'G':
                                    map.G = map.G - 10;
                                    player1_points = player1_points + 1;
                                    printf("You now have %d points!", player1_points);
                                break;
                                case 'I':
                                    map.I = map.I - 10;
                                    player1_points = player1_points + 1;
                                    printf("You now have %d points!", player1_points);
                                break;
                                
                            }
                            
                    }
                    else 
                        printf("You don't have enough resources!\n");
                        
                
            }
        drawMap();
        printf("PL2 choose your action\n");
        printf("r - to roll dice\n");
        printf("p - to use 10 resources to get 1 point\n");
        scanf("%s",&escolha3);
        while (true){
            switch(escolha3){
                case 'r':
                    player2Play(map.W2, map.B2, map.L2, map.G2, map.I2);
                break;
                
                case 'p':
                    if (map.W2 >= 10 || map.B2 >= 10 || map.L2 >= 10 || map.G2 >= 10 || map.I2 >= 10 ){
                        printf("W -(%d)wool,   B - (%d)brick,    L -(%d)lumber\n", map.W2, map.B2, map.L2);
                        printf("G -(%d)grain,  I -(%d)Iron\n", map.G2, map.I2);
                        printf("Which resource will you use? ");
                        scanf("%s", &recurso);
                            switch(recurso){
                                case 'W':
                                    map.W2 = map.W2 - 10;
                                    player2_points = player2_points + 1;
                                    printf("You now have %d points!", player2_points);
                                break;
                                case 'B':
                                    map.B2 = map.B2 - 10;
                                    player2_points = player2_points + 1;
                                    printf("You now have %d points!", player2_points);
                                break;
                                case 'L':
                                    map.L2 = map.L2 - 10;
                                    player2_points = player2_points + 1;
                                    printf("You now have %d points!", player2_points);
                                break;
                                case 'G':
                                    map.G2 = map.G2 - 10;
                                    player2_points = player2_points + 1;
                                    printf("You now have %d points!", player2_points);
                                break;
                                case 'I':
                                    map.I2 = map.I2 - 10;
                                    player2_points = player2_points + 1;
                                    printf("You now have %d points!", player2_points);
                                break;
                                
                            }
                            
                    }
                    else 
                        printf("You don't have enough resources!\n");
                        
                
            }
        }
    }
    return 0;
    
}