# Catan em C
João Dias (21803573) e João Cerqueira (21802495)

## Descrição da solução
Este programa está estruturado entre 3 funções: uma função trata de desenhar o mapa, e as outras duas tratam a jogabilidade de cada jogador. O programa começa por apresentar ao utilizador o mapa, e dá a escolher ao Player 1 a posição da sua primeira aldeia no mapa. Em seguida, é oferecida ao Player 2 a mesma escolha. Note-se que não é possível ao Player 2 estabelecer a aldeia no mesmo local que o Player 1 já tinha ocupado, sendo pedida uma nova escolha ao Player 2 caso este escolha um local já ocupado. É agora apresentada uma nova representação do mapa, desta vez já com as aldeias dos jogadores marcadas nas posições escolhidas. É então pedido ao Player 1 que lance os dados, dando início à função definida, e são gerados dois números aleatórios de 1 a 6, simulando o lançamento de dois dados. São atribuídos aos jogadores os recursos devidos de acordo com a soma dos valores dos dados lançados e com os territórios que cada um controla. É oferecida a escolha de jogada ao jogador, e são processados os movimentos no mapa e o uso de recursos, assim como a atribuição de pontos. É passada a vez ao Player 2, a quem são oferecidas as mesmas escolhas, e esta troca de turnos continua até que alguém atinja a pontuação que garante a vitória.



![Fluxograma](catanFluxo2.jpg)

---

## Manual do jogador
Para compilar uma versão do jogo, o utilizador deverá abrir um terminal na localização do ficheiro catan.c e introduzir o comando "make". Depois, para iniciar o programa, é necessário usar o comando ./Catan.

Para jogar, o jogador deve seguir os comandos apresentados no ecrã à medida que o jogo avança.

## Conclusões 
Com este trabalho, que ficou por concluir na sua totalidade, aprendemos como usar estruturas, e que devemos procurar gerir melhor o tempo nos trabalhos futuros.

## Referências
Discussão com o grupo de Miguel Costa, Inácio Amerio e Diogo Henriques.
Código previamente criado para o trabalho da roleta.



